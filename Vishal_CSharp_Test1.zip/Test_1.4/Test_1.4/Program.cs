﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_1._4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string user, pass;
            int count = 0;

            do
            {
                Console.Write("Enter username: ");
                user = Console.ReadLine();

                Console.Write("Enter password: ");
                pass = Console.ReadLine();

                count++;

            }
            while (((user != "abcd") || (pass != "1234"))
                && (count != 3));

            if (count == 3)
                Console.Write("Login fail!");
            else
                Console.Write("Password Entered Sucessfully !");
        }
    }
}
