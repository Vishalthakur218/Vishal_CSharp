﻿using System;

namespace Demo_UserDefinedFunction
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("User defined exception");
            Temprature temp = new Temprature();
            try
            {
                temp.showTemp();
            }
            catch(TempIsZeroException ex)
            {
                Console.WriteLine("Temprature is zero Exception",ex.Message);
                //throw;
            }
        }
    }
}
