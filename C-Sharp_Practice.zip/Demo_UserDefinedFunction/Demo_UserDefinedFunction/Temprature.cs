﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_UserDefinedFunction
{
    public class TempIsZeroException:Exception
    {
        public TempIsZeroException(string message): base(message)
        {

        }
    }
    internal class Temprature
    {
        int temprature = 0;
        public void showTemp()
        {
            if(temprature == 0)
            {
                throw (new TempIsZeroException("Zero Temprature Found"));
            }
            else
            {
                Console.WriteLine("Temprature: {0}", temprature);
            }
        }
    }
}
