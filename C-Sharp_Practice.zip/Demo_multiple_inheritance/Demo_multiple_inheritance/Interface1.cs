﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_multiple_inheritance
{
     interface IBasicCalculator
    {
        int add(int a, int b);
        int subtract(int a, int b);
    }
    interface IScientificCalculator
    {
        float add(float a, float b);
        float subtract(float a, float b);
    }


    class Calculation : IBasicCalculator, IScientificCalculator
    {
        public int add(int a, int b)
        {
            // throw new NotImplementedException();
            Console.WriteLine(" Add From basic");
            return a + b;
        }

        public float add(float a, float b)
        {
            //throw new NotImplementedException();
            Console.WriteLine(" Add From scientific");
            return a + b;
        }

        public int subtract(int a, int b)
        {
            //throw new NotImplementedException();
            Console.WriteLine(" Sub From basic");
            return a - b;
        }

        public float subtract(float a, float b)
        {
            // throw new NotImplementedException();
            Console.WriteLine(" sub From scientific");
            return a - b;
        }
    }
    
}
