﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_list_Generic_collections
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var movies = new List<string>();
            movies.Add(" End game");
            movies.Add(" End game2");
            movies.Add(" End game3");
            movies.Add(" End game4");
            movies.Add(" End game5");

            Console.WriteLine(movies.Count);
            Console.WriteLine(movies.Capacity);
            
            foreach (var item in movies)
            {
                Console.WriteLine(item);
            }

            var x= movies.Contains(" End game");
            Console.WriteLine(x);

            var y = movies.Remove(" End game3");
            foreach (var item in movies)
            {
                Console.WriteLine(item);
            }
        }
    }
}
