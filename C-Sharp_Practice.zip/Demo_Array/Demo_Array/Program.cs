﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Array
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string[] mobilePhone = { "OnePlus", "Iphone", "Samsung", "Redmi" };
            Console.WriteLine(mobilePhone[0]); // displaying element
                                               //Console.WriteLine(mobilePhone[0]="blackberry");


            //display array for loop
            for (int i = 0; i < mobilePhone.Length; i++)
            {
                Console.WriteLine(mobilePhone[i]);
            }
            Console.WriteLine("-----------");

            //display array foreach - no subscript - will traverse every element
            //var is 
            foreach (var item in mobilePhone)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("-----------");

            //sorting array
            Array.Sort(mobilePhone);
            foreach (var item in mobilePhone)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("-----------");

            int[] arr = { 4, 2, 1, 3, 5 };
            arr.
            //for loop
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);

            }
            Console.WriteLine("-----------");

            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("-----------");

            Array.Sort(arr);
            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }
            // max ,min

            Console.WriteLine(arr.Max());
            Console.WriteLine(arr.Min());

            Console.WriteLine("-----------");

            //var result = 0;
            //foreach (var item in arr)
            //{

            //    result += item;
            //}
            //Console.WriteLine("sum = " + result);

            Console.WriteLine(arr.Sum());
            



        }
    }
}
