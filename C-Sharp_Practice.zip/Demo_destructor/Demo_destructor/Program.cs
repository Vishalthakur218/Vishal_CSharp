﻿using System;

namespace Demo_Des
{

    class Complex : IDisposable //idisposible interfaces contains dispose for releasing unmanagble resources files
    {
        int real, img;

        // Defining the constructor
        public Complex()
        {
            real = 0;
            img = 0;
        }

        public void SetValue(int r, int i)
        {
            real = r;
            img = i;
        }

      
        public void DisplayValue()
        {
            Console.WriteLine("Real = " + real);
            Console.WriteLine("Imaginary = " + img);
        }

        public void Dispose()
        {
            Console.WriteLine("Dispose() Method is called to dispose unmanaged resources");
            GC.SuppressFinalize(this);
            
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                Console.WriteLine("Cleaning up all managed resourses - along with chaild object");
            }
        }

        ~Complex()
        {
            Console.WriteLine("Destructor was called");
            // c# compiler will convert this destructor method in finalize method
            Dispose(false);
        }

    } 
    class Program
    {

        static void Main(string[] args)
        {

            Complex C = new Complex();

            
            C.SetValue(2, 3);

           
            C.DisplayValue();
            C.Dispose();

  

        } 

    }

}