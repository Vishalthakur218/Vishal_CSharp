﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Date_Time
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DateTime TodaysDatae = new DateTime(2022,08,21,10,20,45);
            Console.WriteLine(DateTime.Now);
            //Console.WriteLine(DateTime.MinValue);
            //Console.WriteLine(DateTime.MaxValue);
            Console.WriteLine(TodaysDatae.Year);
            Console.WriteLine(TodaysDatae.Month);
            Console.WriteLine(TodaysDatae.Day);
            Console.WriteLine(TodaysDatae.Hour);
            Console.WriteLine(TodaysDatae.Minute);
            Console.WriteLine(TodaysDatae.Second);

            Console.WriteLine(TodaysDatae.DayOfWeek);
            Console.WriteLine(TodaysDatae.ToString("dd MMMM,yy"));
            
        }
    }
}
