﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Xml;

namespace Demo_Culture_info
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Working with culture info");
            //CultureInfo culture = new CultureInfo("en-US");
            //Console.WriteLine(culture.Name);

            //string currentCulture = Thread.CurrentThread.CurrentCulture.DisplayName ;
            //DateTime currentTime = DateTime.Now;

            //string dateinUSA =currentTime.ToString("D", new CultureInfo("en-US"));
            //Console.WriteLine(dateinUSA);

            //string dateinHindi = currentTime.ToString("d", new CultureInfo("hi-IN"));
            //Console.WriteLine(dateinHindi);

            //string dateinJapan = currentTime.ToString("d", new CultureInfo("ja-JP"));
            //Console.WriteLine(dateinJapan);

            //string dateinFrench = currentTime.ToString("D", new CultureInfo("fr-FR"));
            //Console.WriteLine(dateinFrench);

            CultureInfo currentculture= Thread.CurrentThread.CurrentCulture;
            Calendar cl = currentculture.Calendar;
            //string temp = cl.ToString().Replace("System.Globalization.", "");
            Calendar myCalender = new HijriCalendar();
            DateTime dt = new DateTime(2022, 01, 09, myCalender);
            Console.WriteLine(" Hijri Calender - "+ dt.Year); 
            Console.WriteLine(" Hijri Calender - "+ dt.Month); 
            Console.WriteLine(" Hijri Calender - "+ dt.ToString("D")); 

        }
    }
}
