﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_HashTable_nonGeneric
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Hashtable myht = new Hashtable();
            myht.Add(1, "vishal");
            myht.Add(2, "ankit");
            myht.Add(3, "shivam");

            foreach (DictionaryEntry item in myht)
            {
                Console.WriteLine($"key:{item.Key},Value: {item.Value}");
            }

            myht.Remove(2);
            Console.WriteLine("------");
            foreach (DictionaryEntry item in myht)
            {
                Console.WriteLine($"key:{item.Key},Value: {item.Value}");
            }

            Console.WriteLine("------");
            Console.WriteLine(myht.Contains(1));
            Console.WriteLine(myht.ContainsKey(1));

        } 
    
    }
}
