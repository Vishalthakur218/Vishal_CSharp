﻿using System;

namespace Demo_Multicast_delegate
{
    public delegate void delmethod(int x, int y); // declaration - creating a delegate - contains refrence of func  
    internal class Program
    {

        public void Add(int x, int y) // signature should be same as of delegate
        {
            Console.WriteLine(" Implementing add");
            Console.WriteLine(x+y);
        }
        public void Sub(int x, int y)
        {
            Console.WriteLine(" Implementing sub");
            Console.WriteLine(x-y);
        }
        static void Main(string[] args)
        {
            Program obj1 = new Program(); // obj of class
            delmethod del1 = new delmethod(obj1.Add); // creating ref ->add func
            // Multicasting delegate
             del1 += new delmethod(obj1.Sub); // ref of 2 methods
            del1(45,25);
            Console.WriteLine("-------");
            del1-= new delmethod(obj1.Add); // removing add func
            del1(10, 8);
            
        }
    }
}
