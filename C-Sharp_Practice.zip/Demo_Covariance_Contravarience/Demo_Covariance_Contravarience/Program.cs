﻿using System;

namespace Demo_Covariance_Contravarience
{
    static string GetString()
    {
        return " Sample text";
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            object[] objArray = new string[10]; // assigining a string array to an object array variable.
            objArray[0] ="12";
            Console.WriteLine(objArray[0]);

            Console.WriteLine("delegate covariance");
            Func<object> delegateobj = GetString;
            //string strobj= delegateobj()
        }
    }
}
