﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectPooling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Factory fa = new Factory();
            Employee myEmp = fa.GetEmployee();
            Console.WriteLine("First object");
            Employee myEmp1 = fa.GetEmployee();
            Console.WriteLine("Second object");

           
        }

    }
}
