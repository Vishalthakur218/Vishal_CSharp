﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_param
{
    internal class Program
    {

        public void Show(params int[] val)
        {
            for (int i = 0; i < val.Length; i++)
            {
                Console.WriteLine(val[i]);
            }
        }

        public void func(params object[] emp)
        {
            for(int i = 0; i < emp.Length; i++)
            {
                Console.WriteLine(emp[i]);
            }
        }
        static void Main(string[] args)
        {
            //Program mydData = new Program();
            //mydData.Show(9,8,7,6,10);

            //Program newData = new Program();
            //newData.Show(20,30);

            Program Employee = new Program();
            Employee.func("Vishal", 22, "vishal@gmail.com", "chandigarh");

            Console.WriteLine("=====");

            Program Employee2 = new Program();
            Employee2.func("Thakur", 21, "thakur@gmail.com", "haryana");


        }
    }
}
