﻿using System;

namespace Demo_operator_overloading
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Calculator calc1 = new Calculator(25, -55);
            //calc1 = -calc1;
            //calc1.print();

            Calculator op1 = new Calculator(10, 20);
            Calculator op2 = new Calculator(1, 2);
            Calculator op3 = new Calculator(0, 0);
            op3=op1+ op2;
            op3.print();
            

        }
    }
}