﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_operator_overloading
{
    internal class Calculator
    {
        
        
            public int n1, n2;
            public Calculator(int num1, int num2)
            {
                n1 = num1;
                n2 = num2;
            }
            public static Calculator operator -(Calculator c1)
            {
                c1.n1 = -c1.n1;
                c1.n2 = -c1.n2;
                return c1;
            }
        public static Calculator operator +(Calculator cal1, Calculator cal2)
        {
            Calculator cal = new Calculator(0,0);
            cal.n1 = cal1.n1 + cal2.n1;
            cal.n2 = cal1.n2 + cal2.n2;
            return cal;
        }
        public void print()
            {
                Console.WriteLine("Number 1 =" + n1);
                Console.WriteLine("Number 2 =" + n2);
            }
        }
    }


