﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Inheritance
{
    internal class Program
    {
        static void Main(string[] args)
        {

            NewChild childobj = new NewChild();
            childobj.read("vishal","cse");

            Cousin cousinobj = new Cousin();
            cousinobj.read("ankiy", "ece");

        }
    }
}
