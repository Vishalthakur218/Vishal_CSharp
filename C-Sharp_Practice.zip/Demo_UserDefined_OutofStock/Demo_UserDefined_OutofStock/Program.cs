﻿using System;

namespace Demo_Exception_Stock
{

    class Stock : Exception
    {
        public Stock(string message) : base(message)
        {
            // Console.WriteLine(a);
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter how many goods you want to buy:");
            int order = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("You want to but: " + order + " units ");

            try
            {
                if (order > 5)
                {
                    throw new Stock("oh no order is greter than 5 , we have only 5  items");

                }
                else
                    Console.WriteLine("Happy Shopping");


            }

            catch (Stock s)
            {
                Console.WriteLine(s);
            }

        }
    }
}
