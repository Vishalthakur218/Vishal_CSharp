﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_stack_queue
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Stack stack = new Stack();
          
            stack.Push(1);
            stack.Push("vishal");
            stack.Push(88);
            stack.Push(true);
            stack.Push(67.8);
            stack.Push('A');
            
            foreach (object item in stack)
            {
                Console.WriteLine(item);
            }

            var x= stack.Pop();
            Console.WriteLine(x);

            var y = stack.Peek();
            Console.WriteLine(y);

            Console.WriteLine("-----");

            if (stack.Contains("vishal") == true)
            {
                Console.WriteLine("Element found");
            }
            else
            {
                Console.WriteLine("Element  not found");
            }

        }
    }
}
