﻿using System;

namespace Demo_Exception_age
{

    class Age : Exception
    {
        public Age( string message):base(message)
        {
           // Console.WriteLine(a);
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your age:");
            int age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Your age is: " + age);

            try
            {
                if (age < 20)
                {
                    throw new Age("Invalid Age !!!!");

                }
                else
                    Console.WriteLine("Valid age!!!!");


            }

            catch(Age ax)
            {
                Console.WriteLine(ax);
            }

        }
    }
}
