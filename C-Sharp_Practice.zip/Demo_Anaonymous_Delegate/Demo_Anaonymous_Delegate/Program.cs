﻿using System;

namespace Demo_Anaonymous_Delegate
{
    public delegate void Mydelegate();

    internal class Program
    {
        
        static void Main(string[] args)
        {
            Mydelegate del1 = delegate ()
                {
                    Console.WriteLine("Anonymous Delegate method");
                };
            Mydelegate del2 = delegate ()
            {
                Console.WriteLine("Anonymous Delegate method");
            };
            Mydelegate del3 = del1+del2;
            
            del1();

        }
    }
}
