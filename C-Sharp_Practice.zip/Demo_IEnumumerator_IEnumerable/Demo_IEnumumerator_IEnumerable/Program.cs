﻿using System;
using System.Collections.Generic;

namespace Demo_IEnumumerator_IEnumerable
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> Month = new List<string>();
            Month.Add("January");
            Month.Add("February");
            Month.Add("March");
            

            IEnumerable<string> iEnumerableString = (IEnumerable<string>)Month;
            foreach (string str in iEnumerableString)
            {
                Console.WriteLine(str);
            }

            IEnumerator<string> iEnumeratorOfString = Month.GetEnumerator();

            while (iEnumeratorOfString.MoveNext())
            {
                Console.WriteLine(iEnumeratorOfString.Current);
            }

            // both interfaces are used to loop through collection
        }
    }
}