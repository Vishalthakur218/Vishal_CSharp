﻿using System;

namespace Demo_Memory
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Complex C=new Complex();
            C.SetValue(4, 7);
            C.DisplayValue();
            Complex c1 = new Complex();
            c1.DisplayValue();
            Console.WriteLine("End of code");
        }
    }
}
