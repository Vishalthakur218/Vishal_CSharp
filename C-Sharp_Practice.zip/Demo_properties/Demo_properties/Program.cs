﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_properties
{
    internal class Program
    {   
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Properties");
            Student newStudent = new Student();
            newStudent.Id = 1;
            newStudent.Name = "vishal";
            //Console.Write(newStudent.Id + " ");
            //Console.WriteLine(newStudent.Name);

            //Console.WriteLine(newStudent.AadharNo);

            newStudent[0] = "ankit";
            newStudent[1] = "Neetish";
            newStudent[2] = "Shivam";

            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine(newStudent[i]);
            }

      

        }
    }
}
