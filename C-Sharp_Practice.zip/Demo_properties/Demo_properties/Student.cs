﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_properties
{
    internal class Student
    {
        private string[] names = new string[25];
        //indexers
        public string this [int i]
        {
            get { return names [i]; }
            set { names [i] = value; }
        }





        public int AadharNo 
        {
            get { return 1234; }
        } // read only property
        public int Id { get; set; }
        private string FacebookLink; // private field
        public string name; // field
        public string Name // property
        {
            get { return name; }
            set { name = value; }
        }
    }
}
