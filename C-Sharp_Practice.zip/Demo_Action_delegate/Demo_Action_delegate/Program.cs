﻿using System;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;


namespace Demo_Action_delegate
{
    internal class Program
    {
        public static void Display(string message)
        {
            Console.WriteLine("here we are instantiating Action(T> delegateninsted of explicitly defining a new delegate ");
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Action Delegate");

            Action<string> messsagetarget;
            if(Environment.GetCommandLineArgs().Length > 1)
            {
                messsagetarget = Display;
            }
            else
            {
                messsagetarget = Console.WriteLine;
                messsagetarget("else");
                

            }

         
        }
    }
}
