﻿using System;

namespace Demo_Exception_handling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 123;
            string s = "hi";
            object obj = s; // OBJ CONTAINS STRING
           

            try
            {
                i = (int)obj;
                Console.WriteLine("This is at the end of try block.......");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Catching the {0} exception triggers the finally block.....", ex.GetType());
                throw;


            }
            finally
            {
                Console.WriteLine("Executing thr finally block......");
                Console.WriteLine("i={0}",i);
            }
        }
    }
}
