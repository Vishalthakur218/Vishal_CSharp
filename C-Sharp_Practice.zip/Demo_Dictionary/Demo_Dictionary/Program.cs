﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Dictionary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Dictionary<string, string> Emplist = new Dictionary<string, string>();
            //Emplist.Add("Aman", "sde");
            //Emplist.Add("Avinash", "tester");
            //Emplist.Add("Karthik", "office boy");

            //foreach (KeyValuePair<string, string> item in Emplist)
            //{
            //    Console.WriteLine($"Name:{item.Key} and Dept: {item.Value}");
            //}

            //Console.WriteLine("display only values");
            //foreach(var item in Emplist.Values)
            //{
            //    Console.WriteLine("value from the list: "+item);
            //}

            //Console.WriteLine("display only keys");
            //foreach (var item in Emplist.Keys)
            //{
            //    Console.WriteLine("value from the list: " + item);
            //}


            Dictionary<string, Int16> AuthorList= new Dictionary<string, Int16>();
            AuthorList.Add("Vishal", 1);
            AuthorList.Add("ankit", 2);
            AuthorList.Add("shivam", 3);

            foreach (KeyValuePair<string, Int16> item in AuthorList)
            {
                Console.WriteLine($"Name:{item.Key} and id: {item.Value}");
            }

            AuthorList.Remove("shivam");
            Console.WriteLine("dictionary after removing a element");
            foreach (KeyValuePair<string, Int16> item in AuthorList)
            {
                Console.WriteLine($"Name:{item.Key} and Dept: {item.Value}");
            }

            // AuthorList.Clear();

            Console.WriteLine(AuthorList.ContainsKey("Vishal"));
            Console.WriteLine(AuthorList.ContainsValue(1));

            Console.WriteLine(AuthorList.Count());

            AuthorList.Sort





            Console.WriteLine("---------------------");




            Dictionary<string, float> PrizeList = new Dictionary<string, float>();
            PrizeList.Add("apple", 44.9f);
            PrizeList.Add("Mango", 12.9f);
            PrizeList.Add("Banana", 33.9f);

            foreach (KeyValuePair<string, float> item in PrizeList)
            {
                Console.WriteLine($"Name:{item.Key} and Prize: {item.Value}");
            }

            Console.WriteLine("------------");
            AuthorList.Remove("apple");

        }
    }
}
