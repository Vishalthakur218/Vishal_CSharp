﻿using System;

namespace Demo_Contravariance
{
   // public delegate void mydelegate(); // user defined delegate

    internal class Program
    {   
        
        static void Setobject(object val1) { }
        static void SetString(string val2) { }

        static void Main(string[] args)
        {
            Console.WriteLine("contravariance");

            Action<string> del1 = Setobject; // action is inbulit generic type delegate
            // here a delegate specifies a parameter type as string, still we assign a method that
            // here it is allowing a method that have parameter type less derived than what is specified in the delegate
        }
    }
}
