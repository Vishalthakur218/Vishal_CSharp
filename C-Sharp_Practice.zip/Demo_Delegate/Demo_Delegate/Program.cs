﻿using Microsoft.VisualBasic;
using System;

namespace Demo_Delegate
{
    class MyProgram
    {
        public delegate void delmethod(); // delegate declaration


        internal class Program
        {

            public static void display()
            {
                Console.WriteLine("Inside Display()");

            }
            public static void show()
            {
                Console.WriteLine("Inside show()");

            }
            public void print()
            {
                Console.WriteLine(" Inside Print");
            }

            static void Main(string[] args)
            {
                Console.WriteLine("Singlecast delegates!!!!!!!");
            //Assigining static method show() to delegate delmethod()
            
                delmethod del1 = Program.show;
                delmethod del2 = new delmethod(Program.display); // with help of new operator
                Program obj1 = new Program(); // non static method requires object
                delmethod del3 = obj1.print;
                del1();
                del2();
                del3();
            }
        }
    }
}
