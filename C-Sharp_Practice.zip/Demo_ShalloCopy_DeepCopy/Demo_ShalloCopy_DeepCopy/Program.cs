﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Demo_ShalloCopy_DeepCopy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Shallow obj = new Shallow();
            Shallow objClone = obj;
            obj.i = 101;
            Console.WriteLine(obj.i);
            Console.WriteLine(objClone.i);

            Console.WriteLine("-------------");

            Shallow obj2=(Shallow)obj.Clone();
            obj.i = 200;
            Console.WriteLine( obj2.i);
        }

    }
}
