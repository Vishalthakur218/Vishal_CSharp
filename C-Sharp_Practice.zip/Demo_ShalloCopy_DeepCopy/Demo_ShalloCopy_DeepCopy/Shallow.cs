﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_ShalloCopy_DeepCopy
{
    internal class Shallow : ICloneable
    {
        public int i { get; set; }
        public int j { get; set; }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
