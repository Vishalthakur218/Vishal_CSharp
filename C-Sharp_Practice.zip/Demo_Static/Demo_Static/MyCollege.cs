﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Static
{
    static class MyCollege
    {
        public static string CollegeName;
        public static string CollegeAddress;
        public static string CollegeCity;

        

        static MyCollege()
        {
            CollegeName = "PEC";
            CollegeAddress = "sector 12 - Chandigarh";
            CollegeCity = "Chandigarh";
            
        }
    }
}
