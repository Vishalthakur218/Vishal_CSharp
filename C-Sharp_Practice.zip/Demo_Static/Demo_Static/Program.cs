﻿using System;

namespace Demo_Static
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(MyCollege.CollegeName);
            Console.WriteLine(MyCollege.CollegeAddress);
            Console.WriteLine(MyCollege.CollegeCity);
        }
    }
}
