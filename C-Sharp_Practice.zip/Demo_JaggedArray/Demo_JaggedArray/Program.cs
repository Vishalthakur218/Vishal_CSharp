﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_JaggedArray
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int[][] arr = new int[3][];
            arr[0] = new int[4] { 11, 21, 31, 41 };
            arr[1] = new int[6] { 12, 22, 32, 42, 52, 62 };
            arr[2] = new int[] { 13, 23, 33, 43, 53, 63, 73 };

            //foreach (var i in arr)
            //{
            //    Console.WriteLine();

            //    foreach (var j in i)
            //    {
            //        Console.Write(j+ " ");
            //    }
            //}


            for (int n = 0; n < arr.Length; n++)
            {
                Console.Write("Row -  ", n);

                for (int k = 0; k < arr[n].Length; k++)
                {
                    Console.Write("{0} ", arr[n][k]);
                }
                Console.WriteLine( );
               
            }
        }
    }
}