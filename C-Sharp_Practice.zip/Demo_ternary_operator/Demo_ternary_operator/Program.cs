﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_ternary_operator
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int x = 20, y = 100;
            var result = x > y ? "x is greater " : "x is smaller";
            Console.WriteLine(result);
        }
    }
}
