﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_1._2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Write a program in C# to find Unique element
            int[] arr = { 1, 5, 1 };
            arr.Distinct();
            foreach (int i in arr)
            {
                Console.WriteLine(arr[i]);
            }
        }
    }
}
