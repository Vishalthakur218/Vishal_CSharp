﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_if_else_Condition
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine(" Working with if else ");
            Console.WriteLine(" Enter your age");
            int age = Convert.ToInt32(Console.ReadLine());

            if (age >= 18)
            {
                Console.WriteLine(" You are eligible for voting in india");
            }

            else
            {
                Console.WriteLine("you are minor");
            }
        }
    }
}
