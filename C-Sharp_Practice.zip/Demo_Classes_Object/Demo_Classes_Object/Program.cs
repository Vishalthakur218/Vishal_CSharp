﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Classes_Object
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Car obj1 = new Car();
            Console.WriteLine(obj1.color);

        }
    }

    class Car
    {
       public string color = "Blue";
    }
}
