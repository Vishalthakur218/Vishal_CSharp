﻿using System;

namespace Demo_Equality_Value_reference
{
    public struct Mystruct
    {
        public string Name { get; set; }
        public int id { get; set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with Equality");

            Member obj1 = new Member { id = 1, Name = "Ronaldo", Address = "gokuldham society" };
            Member obj2 = new Member { id = 1, Name = "Ronaldo", Address = "gokuldham society" };
            Member obj3 = obj1; // we have two ref for same memory location
            //Member obj2 = new Member { id = 2, Name = "Messi", Address = " Naya Gaon" };

            Console.WriteLine("lets check if two objects have same or unique values : \n");

            Console.WriteLine(obj1==obj2); // if both obj points to same location
            Console.WriteLine(obj1.Equals(obj2)); 
            Console.WriteLine(System.Object.ReferenceEquals(obj1,obj2));

            Console.WriteLine("Comparing hashcode");
            Console.WriteLine(obj1.GetHashCode());
            Console.WriteLine(obj2.GetHashCode());

            obj1 = obj2;
            Console.WriteLine(obj1==obj3);
            Console.WriteLine(obj1.Equals(obj3));
            Console.WriteLine(System.Object.ReferenceEquals(obj1,obj3));

            Console.WriteLine("Comparing hashcode");
            Console.WriteLine(obj1.GetHashCode());
            Console.WriteLine(obj2.GetHashCode());

            Console.WriteLine("value type using structure");
            Mystruct mystruct1 = new Mystruct { id = 1, Name = "jethalal" };
            Mystruct mystruct2 = new Mystruct { id = 1, Name = "jethalal" };
            // Console.WriteLine(mystruct1==mystruct2); // compile time error

            Console.WriteLine(System.Object.ReferenceEquals(mystruct1,mystruct2)); 
            Console.WriteLine(mystruct1.Equals(mystruct2)); // checking value



        }
    }
}
