﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_String
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string mystring = "TEST";
            char[] str1 = { 'T', 'E', 'S', 'T' };
            Console.WriteLine(mystring);
            Console.WriteLine(str1);
            //if(mystring == str1.ToString())
            //{
            //    Console.WriteLine("same");

            //}
            //else Console.WriteLine("fool");
            Console.WriteLine(mystring.CompareTo(str1.ToString())); 
        }
    }
}
