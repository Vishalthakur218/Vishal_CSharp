﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Maths_namespace
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine(Math.Sqrt(2));
            Console.WriteLine(Math.Min(2,3));
            Console.WriteLine(Math.Abs(-22));
            Console.WriteLine(Math.Round(2.51));
            Console.WriteLine(Math.Pow(2,3));
            

        }


    }
}
